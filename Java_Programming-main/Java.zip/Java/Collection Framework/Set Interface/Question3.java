import java.util.HashSet;
public class Question3{
    public static void main(String[] args){
        HashSet ans=new HashSet<>();

        ans.add(1);
        ans.add(20);
        ans.add(10);

        ans.add("Rohit");

        System.out.println(ans);
    }
}