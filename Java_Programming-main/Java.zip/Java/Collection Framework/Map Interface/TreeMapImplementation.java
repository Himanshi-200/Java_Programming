import java.util.*;
public class TreeMapImplementation {
    public static void main(String[] args){
        Map<Integer, String>ans=new TreeMap<>();

        ans.put(1,"Rohit");
        ans.put(3,"Rahul");
        ans.put(2,"Rohan");

        System.out.println(ans);
    }
}
