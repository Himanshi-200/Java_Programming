package List Interface.Queue Interface;

public class LinkedListImplementation {
    
}
