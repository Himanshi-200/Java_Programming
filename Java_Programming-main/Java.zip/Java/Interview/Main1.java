public class Main1 {
    public static void main(String[] args) {
        String[] pattern = {"A", "A A", "A A P", "A A P T", "T A T T", "T A T", "T A", "T"};
        
        for (int i = 0; i < pattern.length; i++) {
            System.out.println(pattern[i]);
        }
    }
}