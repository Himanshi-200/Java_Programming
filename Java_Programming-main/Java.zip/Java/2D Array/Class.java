public class Class{
    int id=101;
    String name="Rohit";

    public static void main(String[] args){
        Class obj=new Class();

        System.out.println(obj.id);
        System.out.println(obj.name);
    }
}