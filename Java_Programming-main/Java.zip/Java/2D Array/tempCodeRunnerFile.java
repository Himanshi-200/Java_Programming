
        printMatrix(ans);