public class CreateString {
    public static void main(String[] args) {
        String a="Rohit";
        String b="Rohit";

        System.out.println(a);
        System.out.println(b);

        String c=new String("Rohit");
        String d="Rohit";

        System.out.println(c);
        System.out.println(d);
    }
}
