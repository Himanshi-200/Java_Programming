
public class StringLiteral{
    public static void main(String[] args){

        String a="Rohit";
        String b="Rohit";

        System.out.println(a);
        System.out.println(b);

        a.concat("kumar");
        System.out.println(a);
    }
}