public class PrintSubstringString {
    public static void main(String[] args){
        
        String str="abcd";

        for(int i=0; i<=3; i++){
            for(int j=i+1; i<=4; j++){
                System.out.print(str.substring(i,j)+" ");
            }
        }
    }
}
