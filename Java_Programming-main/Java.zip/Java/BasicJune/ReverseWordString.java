import java.util.Scanner;
public class ReverseWordString {

    public static String reverseString(String str){

        //Method 1
        // char ch[]=str.toCharArray();

        // String reverse="";
        // for(int i=ch.length-1; i>=0; i--){
        //     reverse=reverse+ch[i];
        // }

        // return reverse;
        
        //Methiod 2
        String[] arr=str.split(" ");
        String reverse="";
        for(int i=arr.length-1; i>=0; i--){
            reverse=reverse+arr[i]+" ";
        }
        return reverse;

    }
    
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);

        System.out.println("Enter the String:- ");
        String str=sc.nextLine();

        System.out.println(reverseString(str));
    }
}
