class ImplementionOfLinkedList{

    Node head;
    class Node{
        String data;
        Node next;

        Node(String data){
            this.data=data;
            this.next=null;
        }
    }
    public static void main(String[] args){
        ImplementionOfLinkedList ll=new ImplementionOfLinkedList();
    }
}